_addon.author   = 'Project Tako';
_addon.name     = 'Faster CS';
_addon.version  = '1.0';

require('common');
require('ffxi.targets');

local options =
{
    ['DisableInMenu'] = true,
    ['DefaultFps'] = 1,
    ['Enabled'] = false,
    ['Debug'] = false
};

-- imgui controls and variables
local imgui_variables =
{
	['var_ShowWindow'] = { nil, ImGuiVar_BOOLCPP, false },
    ['var_DisableInMenu_Checkbox'] = { nil, ImGuiVar_BOOLCPP, true },
    ['var_DefaultFps_Combo'] = { nil, ImGuiVar_INT32, 0 },
    ['var_TargetName_Input'] = { nil, ImGuiVar_CDSTRING, 20, '' }
};

local divisors =
{
    [1] = -1,
    [2] = 0,
    [3] = 1,
    [4] = 2
};

local excluded_npcs =
T{

};

local fps_info =
{
    ['Pointer'] = 0
}

local menu_info =
{
    ['Pointer'] = 0,
    -- below is just for easy debugging
    ['CurrentMenu'] = 0,
    ['Index'] = -1,
    ['Count'] = -1,
    ['MenuName'] = nil
};

--I got this from fps.lua (thanks Atom0s)
local function read_fps_divisor()
	if (fps_info['Pointer'] ~= 0) then
	    return ashita.memory.read_uint32(fps_info['Pointer'] + 0x30);
	end

    return 2;
end

local function write_fps_divisor(divisor)
    if (type(divisor) ~= "number") then return; end

	if (fps_info['Pointer'] == 0) then return; end

    ashita.memory.write_uint32(fps_info['Pointer'] + 0x30, divisor);
end

local function get_menu_name()
    menu_info['CurrentMenu'] = 0;
    menu_info['Index'] = 0;
    menu_info['Count'] = 0;
    menu_info['MenuName'] = nil;

    if (menu_info['Pointer'] == 0) then return 'None'; end

    menu_info['CurrentMenu'] = ashita.memory.read_uint32(menu_info['Pointer']);
    if (menu_info['CurrentMenu'] == 0) then return 'None'; end

    menu_info['Index'] = ashita.memory.read_uint16(menu_info['CurrentMenu'] + 0x4C);
    menu_info['Count'] = ashita.memory.read_uint16(menu_info['CurrentMenu'] + 0x58);

    local info = ashita.memory.read_uint32(menu_info['CurrentMenu'] + 0x04);
    if (info == 0) then return 'None'; end

    menu_info['MenuName'] = ashita.memory.read_string(info + 0x46, 0x10) or 'None';

    return menu_info['MenuName'];
end

---------------------------------------------------------------------------------------------------
-- func: load
-- desc: First called when our addon is loaded.
---------------------------------------------------------------------------------------------------
ashita.register_event('load', function()
    -- load settings
    options = ashita.settings.load_merged(_addon.path .. '/settings/settings.json', options) or { };

    -- set some imgui variables 
    imgui_variables['var_DisableInMenu_Checkbox'][3] = options['DisableInMenu'];
    imgui_variables['var_DefaultFps_Combo'][1] = options['DefaultFps'];

    excluded_npcs = ashita.settings.load_merged(_addon.path .. '/settings/excluded_npcs.json', excluded_npcs) or T{ };

    -- initialize imgui and it's variables
	for key, value in pairs(imgui_variables) do
		if (type(value) == 'table') then
			if (value[2] >= ImGuiVar_CDSTRING) then
				value[1] = imgui.CreateVar(value[2], value[3]);
			else
				value[1] = imgui.CreateVar(value[2]);
			end

			-- if default value, set it
			if (#value > 2 and value[2] < ImGuiVar_CDSTRING) then
				imgui.SetVarValue(value[1], value[3]);
			elseif (#value > 3 and value[2] == ImGuiVar_CDSTRING) then
				imgui.SetVarValue(value[1], value[4]);
			end
		end
    end

    imgui.SetNextWindowSize(400, 300, ImGuiSetCond_FirstUseEver);

    local pointer = ashita.memory.findpattern('FFXiMain.dll', 0, '8B480C85C974??8B510885D274??3B05', 0x10, 0);
    if (pointer ~= 0) then
        local menu_info_pointer = ashita.memory.read_uint32(pointer);
        if (menu_info_pointer ~= 0) then
            menu_info['Pointer'] = menu_info_pointer;
        end
    end

    pointer = ashita.memory.findpattern('FFXiMain.dll', 0, '81EC000100003BC174218B0D', 0, 0);
    if (pointer ~= 0) then
        fps_info['Pointer'] = ashita.memory.read_uint32(ashita.memory.read_uint32(pointer + 0x0C));
    end

    divisors[1] = read_fps_divisor();

    local player = GetPlayerEntity();
	-- status 4 is 'event' status
	if (player ~= nil and player['Status'] == 4) then
		write_fps_divisor(divisors[2]);
        options['Enabled'] = true;
	end

    local menu_name = get_menu_name();
end);

---------------------------------------------------------------------------------------------------
-- func: command
-- desc: Called when our addon receives a command.
---------------------------------------------------------------------------------------------------
ashita.register_event('command', function(cmd, nType)
	-- get command args
	local args = cmd:args();

	if (args[1] ~= '/fastcs' and args[1] ~= 'fcs') then
		return false;
	end

    if (#args < 2) then
        return false;
    end

    if (args[2] == 'show' or args[2] == 'options') then
        imgui.SetVarValue(imgui_variables['var_ShowWindow'][1], true);
    elseif (args[2] == 'hide') then
        imgui.SetVarValue(imgui_variables['var_ShowWindow'][1], false);
    elseif (args[2] == 'toggle') then
        imgui.SetVarValue(imgui_variables['var_ShowWindow'][1], not imgui.GetVarValue(imgui_variables['var_ShowWindow'][1]));
    elseif (args[2] == 'debug') then
        options['Debug'] = not options['Debug'];
    end

	return true;
end);

---------------------------------------------------------------------------------------------------
-- func: incoming_text
-- desc: Called when the game client has begun to add a new line of text to the chat box.
---------------------------------------------------------------------------------------------------
ashita.register_event('incoming_text', function(mode, message, modifiedmode, modifiedmessage, blocked)
    return false;
end);

---------------------------------------------------------------------------------------------------
-- func: outgoing_text
-- desc: Called when the game client is sending text to the server.
--       (This gets called when a command, chat, etc. is not handled by the client and is being sent to the server.)
---------------------------------------------------------------------------------------------------
ashita.register_event('outgoing_text', function(mode, message, modifiedmode, modifiedmessage, blocked)
    return false;
end);

---------------------------------------------------------------------------------------------------
-- func: incoming_packet
-- desc: Called when our addon receives an incoming packet.
---------------------------------------------------------------------------------------------------
ashita.register_event('incoming_packet', function(id, size, packet)
    if (id == 0x037) then
        local status = struct.unpack('b', packet, 0x30 + 1);
        if (status == 0x04) then
            local target = ashita.ffxi.targets.get_target('t');

            if (target == nil) then return false; end
            if (table.hasvalue(excluded_npcs, target['Name'])) then return false; end

            if (options['DisableInMenu'] and get_menu_name() == string.format('%-16s', 'menu    query')) then return false; end

            options['Enabled'] = true;
            write_fps_divisor(divisors[2]);
        else
            options['Enabled'] = false;
            write_fps_divisor(divisors[options['DefaultFps']]);
        end
    end
	return false;
end);

---------------------------------------------------------------------------------------------------
-- func: outgoing_packet
-- desc: Called when our addon receives an outgoing packet.
---------------------------------------------------------------------------------------------------
ashita.register_event('outgoing_packet', function(id, size, packet)
    if (id == 0x00D) then
        options['Enabled'] = false;
        write_fps_divisor(divisors[options['DefaultFps']]);
    end
	return false;
end);

---------------------------------------------------------------------------------------------------
-- func: prerender
-- desc: Called before our addon is about to render.
---------------------------------------------------------------------------------------------------
ashita.register_event('prerender', function()
    if (imgui.GetVarValue(imgui_variables['var_ShowWindow'][1]) == false) then
        return;
    end

    if (imgui.Begin('Faster CS', imgui_variables['var_ShowWindow'][1], 96)) then
        imgui.Text('Options');
        imgui.Separator();

        imgui.Indent(5.0);

        imgui.PushItemWidth(100);
        if (imgui.Checkbox('Disable In Menus', imgui_variables['var_DisableInMenu_Checkbox'][1])) then
            options['DisableInMenu'] = imgui.GetVarValue(imgui_variables['var_DisableInMenu_Checkbox'][1]);

            local player = GetPlayerEntity();
            if (player ~= nil and player['Status'] == 0x04 and options['Enabled']) then
                if (get_menu_name() == string.format('%-16s', 'menu    query')) then
                    if (options['DisableInMenu']) then
                        options['Enabled'] = false;
                        write_fps_divisor(divisors['Auto']);
                    else
                        options['Enabled'] = true;
                        write_fps_divisor(divisors['Uncapped']);
                    end
                end
            end
        end
        imgui.PopItemWidth();
        imgui.PushItemWidth(100);
        if (imgui.Combo('Default FPS', imgui_variables['var_DefaultFps_Combo'][1], 'Auto\0Uncapped\00060 FPS\00030 FPS\0\0')) then
            options['DefaultFps'] = imgui.GetVarValue(imgui_variables['var_DefaultFps_Combo'][1]) + 1;
        end
        imgui.PopItemWidth();

        imgui.Unindent(5.0);

        imgui.NewLine();

        imgui.Text('Exclusions');
        imgui.Separator();

        imgui.Indent(5.0);

        imgui.PushItemWidth(150);
        imgui.PushID(1);
        if (imgui.Button('Add Target')) then
            local target = AshitaCore:GetDataManager():GetTarget();
            local target_name = target:GetTargetName();
            if (target_name and target_name ~= '') then
                table.insert(excluded_npcs, target_name);

                local player = GetPlayerEntity();
                if (player ~= nil and player['Status'] == 0x04 and options['Enabled']) then
                    local target = ashita.ffxi.targets.get_target('t');
                    if (target ~= nil and table.hasvalue(excluded_npcs, target['Name'])) then
                        options['Enabled'] = false;
                        write_fps_divisor(divisors['Auto']);
                    end
                end
            end
        end
        imgui.PopID();
        imgui.PopItemWidth();

        imgui.PushItemWidth(150);
        if (imgui.InputText('Target Name', imgui_variables['var_TargetName_Input'][1], imgui_variables['var_TargetName_Input'][3], ImGuiInputTextFlags_EnterReturnsTrue)) then
            local target_name = imgui.GetVarValue(imgui_variables['var_TargetName_Input'][1]);
            if (target_name ~= nil and target_name ~= '') then
                if (not table.hasvalue(excluded_npcs, target_name)) then
                    table.insert(excluded_npcs, target_name);

                    local player = GetPlayerEntity();
                    if (player ~= nil and player['Status'] == 0x04 and options['Enabled']) then
                        local target = ashita.ffxi.targets.get_target('t');
                        if (target ~= nil and table.hasvalue(excluded_npcs, target['Name'])) then
                            options['Enabled'] = false;
                            write_fps_divisor(divisors['Auto']);
                        end
                    end
                end

                imgui.SetVarValue(imgui_variables['var_TargetName_Input'][1], imgui_variables['var_TargetName_Input'][4]);
            end
        end
        imgui.PopItemWidth();

        if (#excluded_npcs > 0) then
            imgui.PushItemWidth(150);
            if (imgui.ListBoxHeader('##label', 150, imgui.GetTextLineHeight() * 5)) then
                for key, value in pairs(excluded_npcs) do
                    if (imgui_variables[string.format('var_%s_Selectable', value)] == nil) then
                        imgui_variables[string.format('var_%s_Selectable', value)] = { nil, ImGuiVar_BOOLCPP, false };
                        imgui_variables[string.format('var_%s_Selectable', value)][1] = imgui.CreateVar(imgui_variables[string.format('var_%s_Selectable', value)][2], imgui_variables[string.format('var_%s_Selectable', value)][3]);
                    end

                    if (imgui.Selectable(value, imgui_variables[string.format('var_%s_Selectable', value)][1], ImGuiSelectableFlags_AllowDoubleClick)) then
                        if (imgui.IsMouseDoubleClicked(0)) then
                            excluded_npcs[key] = nil;
                        end
                    end
                end
                imgui.ListBoxFooter();
            end
            imgui.PopItemWidth();
        end

        imgui.Unindent(5.0);

        if (options['Debug']) then
            get_menu_name();

            imgui.NewLine();

            imgui.Text('Debug');
            imgui.Separator();

            imgui.Indent(5.0);

            local player = GetPlayerEntity();
            imgui.Text('Player Status: ');
            imgui.SameLine();
            imgui.Text(player ~= nil and player['Status'] or 0);

            imgui.Text('Menu Address: ');
            imgui.SameLine();
            imgui.Text(string.format('0x%X', menu_info['CurrentMenu']));

            imgui.Text('Menu Index: ');
            imgui.SameLine();
            imgui.Text(menu_info['Index']);

            imgui.Text('Menu Count: ');
            imgui.SameLine();
            imgui.Text(menu_info['Count']);

            imgui.Text('Menu Name: ');
            imgui.SameLine();
            imgui.Text(menu_info['MenuName'] or '');

            imgui.Text('Target Name: ');
            imgui.SameLine();
            local target = ashita.ffxi.targets.get_target('t');
            imgui.Text(target and target['Name'] or '');

            imgui.Unindent(5.0);
        end

        imgui.End();
    end
end);

---------------------------------------------------------------------------------------------------
-- func: render
-- desc: Called when our addon is being rendered.
---------------------------------------------------------------------------------------------------
ashita.register_event('render', function()
    local player = GetPlayerEntity();
    if (player == nil) then
        if (options['Enabled']) then
            options['Enabled'] = false;
            write_fps_divisor(divisors[options['DefaultFps']]); 
        end

        return;
    end

    if (player['Status'] == 0x04) then
        local target = ashita.ffxi.targets.get_target('t');

        if (target ~= nil and table.hasvalue(excluded_npcs, target['Name'])) then
            options['Enabled'] = false;
            write_fps_divisor(divisors[options['DefaultFps']]);
        elseif (options['DisableInMenu'] and get_menu_name() == string.format('%-16s', 'menu    query')) then 
            options['Enabled'] = false;
            write_fps_divisor(divisors[options['DefaultFps']]);
        elseif (not options['Enabled']) then
            options['Enabled'] = true;
            write_fps_divisor(divisors[2]);
        end
    elseif (options['Enabled']) then
        options['Enabled'] = false;
        write_fps_divisor(divisors[options['DefaultFps']]);
    end
end);

---------------------------------------------------------------------------------------------------
-- func: timer_pulse
-- desc: Called when our addon is rendering it's scene.
---------------------------------------------------------------------------------------------------
ashita.register_event('timer_pulse', function()

end);

---------------------------------------------------------------------------------------------------
-- func: unload
-- desc: Called when our addon is unloaded.
---------------------------------------------------------------------------------------------------
ashita.register_event('unload', function()
    ashita.settings.save(_addon.path .. '/settings/settings.json', options);
    ashita.settings.save(_addon.path .. '/settings/excluded_npcs.json', excluded_npcs);
end);